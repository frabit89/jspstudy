
package com.gdu.prj.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.gdu.prj.dto.StudentDto;

public class StudentDaoImpl implements StudentDao {

  private Connection con;
  private PreparedStatement ps;
  private ResultSet rs;
  
  private DataSource dataSource;
  
  private static StudentDao studentDao = new StudentDaoImpl();
  
  private void StudentDaoImpl() {
    try {
      Context context = new InitialContext();
      Context env = (Context)context.lookup("java:comp/env"); // 파일 자체를 찾기 위한 문법
      dataSource = (DataSource)env.lookup("jdbc/myoracle"); // 어떤 리소스를 가지고 올 것인가
    } catch (NamingException e) {
      System.out.println("관련 자원을 찾을 수 없습니다.");
    }
  }
  
  public static StudentDao getInstance() {
    return studentDao;
  }
  
  @Override
  public int insertStudent(StudentDto student) {
    // TODO Auto-generated method stub
    return 0;
  }

  @Override
  public int modifyStudent(StudentDto student) {
    // TODO Auto-generated method stub
    return 0;
  }

  @Override
  public int deleteStudent(int student_no) {
    // TODO Auto-generated method stub
    return 0;
  }

  @Override
  public List<StudentDto> selectStudentList(Map<String, Object> params) {
    List<StudentDto> studentList = new ArrayList<StudentDto>();
    try {
      con = dataSource.getConnection();
      String sql = "SELECT STU_NO, NAME, KOR, ENG, MATH, AVE, MARK"
                + "   FROM ROW_NUMBER() OVER(ORDER BY STU_NO " + params.get("sort") + ") AS RN, STU_NO, NAME, KOR, ENG, MATH, AVE, MARK"
                + "  WHERE RN BETWEEN ? AND ?";
      ps = con.prepareStatement(sql);
      ps.setInt(1, (int)params.get(studentList));
      ps.setInt(2, (int)params.get(studentList));
      rs = ps.executeQuery();
    }
      catch(Exception e) {
      
    }
  }

  @Override
  public int getStudentCount() {
    // TODO Auto-generated method stub
    return 0;
  }

  @Override
  public StudentDto selectBoardByNo(int board_no) {
    // TODO Auto-generated method stub
    return null;
  }

}
